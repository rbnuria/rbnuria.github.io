<template><div class="foot"><span>MODELOS DE COMPUTACIÓN · AUTÓMATA PRODUCTO · EJERCICIO 12.c</span><span>{{ $slidev.nav.currentPage }} / {{ $slidev.nav.total }}</span></div></template>
