<script setup>
import {computed,useId} from 'vue'
const p=defineProps({mode:{default:'product'},stage:{default:4},op:{default:'intersection'},active:{default:''}})
const uid=useId().replace(/:/g,'')
const ink='#23384d',teal='#168478',rose='#b55277'
const nodes=computed(()=>p.mode==='ones'?[['r₀',180,215],['r₁',480,215],['r₂',780,215]]:p.mode==='zeros'?[['P',300,210],['I',660,210]]:[['r₀,P',180,140],['r₁,P',480,140],['r₂,P',780,140],['r₀,I',180,330],['r₁,I',480,330],['r₂,I',780,330]])
const finals=computed(()=>p.mode==='ones'?[1,2]:p.mode==='zeros'?[0]:p.stage<4?[]:p.op==='union'?[0,1,2,4,5]:[1,2])
const edges=computed(()=>{
 let e=[]
 const add=(d,x,y,a)=>e.push({d,x,y,a})
 if(p.mode==='ones'){
  for(const x of [180,480,780]) add(`M${x-23} 183 C${x-100} 80 ${x+100} 80 ${x+23} 183`,x,104,'0')
  add('M222 215 H435',330,198,'1');add('M522 215 H735',630,198,'1');add('M780 258 C780 390 180 390 180 260',480,350,'1')
 }else if(p.mode==='zeros'){
  for(const x of [300,660])add(`M${x-23} 178 C${x-100} 70 ${x+100} 70 ${x+23} 178`,x,95,'1')
  add('M340 194 Q480 90 618 194',480,140,'0');add('M620 227 Q480 350 342 227',480,307,'0')
 }else{
  if(p.stage>=2)for(const x of [180,480,780]){
   add(`M${x-18} 180 Q${x-60} 235 ${x-18} 286`,x-48,244,'0');add(`M${x+18} 290 Q${x+60} 235 ${x+18} 184`,x+48,244,'0')
  }
  if(p.stage>=3){
   for(const y of [140,330]){add(`M222 ${y} H435`,330,y-16,'1');add(`M522 ${y} H735`,630,y-16,'1')}
   add('M780 98 C780 8 180 8 180 96',480,36,'1');add('M780 372 C780 464 180 464 180 374',480,442,'1')
  }
 }
 return e
})
</script>
<template>
<svg class="product-graph" viewBox="0 0 960 480" role="img" :aria-label="'Autómata '+mode+' '+op">
<defs><marker v-for="[key,color] in [['ink',ink],['0',teal],['1',rose]]" :id="uid+key" markerWidth="10" markerHeight="8" refX="8" refY="4" orient="auto"><path d="M0 0 L9 4 L0 8 Z" :fill="color"/></marker></defs>
<g v-for="(e,i) in edges" :key="i"><path :d="e.d" fill="none" :stroke="e.a==='0'?teal:rose" stroke-width="2.7" :marker-end="`url(#${uid+e.a})`"/><text :x="e.x" :y="e.y" text-anchor="middle" :fill="e.a==='0'?teal:rose" class="edge-label">{{e.a}}</text></g>
<path :d="`M${nodes[0][1]-120} ${nodes[0][2]} H${nodes[0][1]-46}`" :stroke="ink" stroke-width="2.6" :marker-end="`url(#${uid}ink)`"/>
<g v-for="(n,i) in nodes" :key="i"><circle :cx="n[1]" :cy="n[2]" r="42" :fill="active===n[0]?'#f3dce4':'#fbf8f1'" :stroke="active===n[0]?rose:ink" :stroke-width="active===n[0]?4:2.4"/><circle v-if="finals.includes(i)" :cx="n[1]" :cy="n[2]" r="35.5" fill="none" :stroke="ink" stroke-width="2"/><text :x="n[1]" :y="n[2]+8" text-anchor="middle" :fill="ink" class="state-label">{{n[0]}}</text></g>
</svg>
</template>
<style scoped>.product-graph{display:block;width:100%;height:305px;margin:0 auto}.state-label{font:24px 'Avenir Next',sans-serif}.edge-label{font:27px 'Avenir Next',sans-serif;paint-order:stroke;stroke:#fbf8f1;stroke-width:8;stroke-linejoin:round}</style>
