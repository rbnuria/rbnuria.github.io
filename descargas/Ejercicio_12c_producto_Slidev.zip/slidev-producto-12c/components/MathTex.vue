<script setup>
import katex from 'katex'
import 'katex/dist/katex.min.css'
defineProps({tex:String,display:Boolean})
</script>
<template><span :class="display?'display-math':'inline-math'" v-html="katex.renderToString(tex,{throwOnError:true,displayMode:display})" /></template>
<style scoped>.display-math{display:block}</style>
