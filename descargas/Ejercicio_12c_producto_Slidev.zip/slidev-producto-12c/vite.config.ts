import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'
export default defineConfig({
  build: { cssMinify: false },
  resolve: { dedupe: ['vue', '@vue/runtime-core', '@vue/runtime-dom', '@vue/reactivity'] },
  server: { fs: { allow: [fileURLToPath(new URL('.', import.meta.url)), fileURLToPath(new URL('../slidev-taller-integrador/node_modules', import.meta.url))] } },
})
