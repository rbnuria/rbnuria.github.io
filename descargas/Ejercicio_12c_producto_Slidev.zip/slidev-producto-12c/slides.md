---
theme: default
author: Nuria Rodríguez Barroso
title: Autómata producto · Ejercicio 12.c
colorSchema: light
aspectRatio: 16/9
canvasWidth: 1100
transition: fade
fonts:
  sans: Avenir Next
  serif: Georgia
  local: Avenir Next,Georgia
  provider: none
drawings:
  persist: false
class: hero
---

<div class="eyebrow">Relación 2 · Ejercicio 12.c</div>

# Autómata producto

<p>Dos condiciones sobre una misma palabra</p>
<MathTex display tex="L=\{u\in\{0,1\}^*:\ |u|_1\not\equiv0\pmod3\ \land\ |u|_0\equiv0\pmod2\}" />
<p class="small">Construcción paso a paso y comparación con la unión de lenguajes</p>
<p class="cover-author">Nuria Rodríguez Barroso</p>

<!-- Enunciado: Relacion_2.pdf, Modelos de Computación, Ingeniería Informática, Grupo C, 24/25, ejercicio 12.c. Desarrollo propio para estas diapositivas. Estilo de las presentaciones de la asignatura. -->

---
clicks: 3
---

<div class="eyebrow">El enunciado</div>

# Las dos condiciones del lenguaje

<p>«El número de 1 no es múltiplo de 3 <strong>y</strong> el número de 0 es par».</p>
<div v-click="1"><MathTex display tex="L_1=\{u:|u|_1\not\equiv0\pmod3\}" /></div>
<div v-click="2"><MathTex display tex="L_2=\{u:|u|_0\equiv0\pmod2\}" /></div>
<div v-click="3" class="result"><MathTex display tex="L=L_1\cap L_2" /><p>El producto sirve para la intersección y para la unión. La operación determina qué pares son finales.</p></div>
<p class="source-line">Fuente del enunciado: Relación 2, Modelos de Computación, Ingeniería Informática, Grupo C, 24/25.</p>

---
clicks: 2
class: component-slide
---

<div class="eyebrow">Primer componente</div>

# Unos: resto de la división entre 3

<ProductGraph mode="ones" />
<div v-click="1"><MathTex display tex="r_i\quad\Longleftrightarrow\quad |u|_1\equiv i\pmod3" /></div>
<div v-click="2" class="note">Un 1 avanza al siguiente resto. Un 0 deja el resto igual.<br>Inicial: r₀. Finales: r₁ y r₂. Cero también es múltiplo de 3.</div>

---
clicks: 2
class: component-slide
---

<div class="eyebrow">Segundo componente</div>

# Ceros: paridad

<ProductGraph mode="zeros" />
<div v-click="1"><MathTex display tex="P:\ |u|_0\equiv0\pmod2\qquad I:\ |u|_0\equiv1\pmod2" /></div>
<div v-click="2" class="note">Un 0 cambia la paridad. Un 1 la conserva.<br>Inicial y único final: P. La palabra ε tiene cero ceros.</div>

---
clicks: 1
class: product-slide
---

<div class="eyebrow">Producto cartesiano</div>

# Seis estados para recordar ambos datos

<MathTex display tex="Q=\{r_0,r_1,r_2\}\times\{P,I\},\qquad q_{\mathrm{inicial}}=(r_0,P)" />
<ProductGraph :stage="1" />
<div v-click="1" class="note">Cada par guarda el resto de unos y la paridad de ceros.<br>Por ejemplo, (r₂,I) significa «unos ≡ 2 (módulo 3) y ceros impares».</div>

---
clicks: 1
class: product-slide
---

<div class="eyebrow">Transiciones del producto</div>

# Al leer 0, cambia la segunda coordenada

<ProductGraph :stage="2" />
<MathTex display tex="\delta((r_i,P),0)=(r_i,I),\qquad\delta((r_i,I),0)=(r_i,P)" />
<div v-click="1" class="note">Ambos autómatas leen el mismo 0. El primero permanece en rᵢ y el segundo cambia de paridad.</div>

---
clicks: 1
class: product-slide
---

<div class="eyebrow">Transiciones del producto</div>

# Al leer 1, cambia la primera coordenada

<ProductGraph :stage="3" />
<MathTex display tex="\delta((r_i,p),1)=(r_{(i+1)\bmod3},p)" />
<div v-click="1" class="note">La regla general es <MathTex tex="\delta((r,p),a)=(\delta_1(r,a),\delta_2(p,a))" />.<br>El símbolo 1 recorre los tres restos sin cambiar de fila.</div>

---
clicks: 1
class: product-slide
---

<div class="eyebrow">Solución del ejercicio 12.c</div>

# Finales de la intersección

<ProductGraph :stage="$clicks === 0 ? 3 : 4" />
<MathTex display tex="F_{\cap}=F_1\times F_2=\{(r_1,P),(r_2,P)\}" />
<div v-click="1" class="note">Un estado es final cuando sus dos componentes son finales.<br>Estos dos pares cumplen a la vez las condiciones del enunciado.</div>

---
clicks: 4
class: product-slide trace
---

<div class="eyebrow">Ejemplo de aceptación</div>

# Lectura de 0011

<ProductGraph :active="['r₀,P','r₀,I','r₀,P','r₁,P','r₂,P'][Math.min($clicks,4)]" />
<div class="trace-caption"><span class="trace-word">{{ '0011'.slice(0, Math.min($clicks,4)) }}<span style="opacity:.25">{{ '0011'.slice(Math.min($clicks,4)) }}</span></span><p>{{ ['Sin leer símbolos: (r₀,P).','Un cero: (r₀,I).','Dos ceros: (r₀,P).','Dos ceros y un uno: (r₁,P).','Dos ceros y dos unos: (r₂,P). Palabra aceptada.'][Math.min($clicks,4)] }}</p></div>

---
clicks: 3
---

<div class="eyebrow">Comprobaciones</div>

# Cuándo se rechaza una palabra

<div v-click="1" class="state-row"><span>00111</span><MathTex tex="(r_0,P)" /><span>Tres unos: múltiplo de 3.</span></div>
<div v-click="2" class="state-row"><span>01</span><MathTex tex="(r_1,I)" /><span>Un cero: cantidad impar.</span></div>
<div v-click="3" class="state-row"><MathTex tex="\varepsilon" /><MathTex tex="(r_0,P)" /><span>Cero unos: múltiplo de 3.</span></div>
<p class="note">Para la intersección basta que falle una condición para rechazar.</p>

---
clicks: 1
class: product-slide union-slide
---

<div class="eyebrow">La variante con «o»</div>

# Finales de la unión de lenguajes

<ProductGraph op="union" :stage="$clicks === 0 ? 3 : 4" />
<div class="formula-small"><MathTex display tex="F_{\cup}=(F_1\times Q_2)\cup(Q_1\times F_2)" /></div>
<div v-click="1" class="note">Se acepta si al menos un componente es final. Solo (r₀,I) rechaza.<br>Esta variante reconoce <MathTex tex="L_1\cup L_2" />: unos no múltiplo de 3 <strong>o</strong> ceros pares.</div>

---
clicks: 2
class: compare
---

<div class="eyebrow">Intersección y unión</div>

# Mismas transiciones, distintos finales

<p>El estado alcanzado conserva la misma información en ambas construcciones.</p>
<div v-click="1" class="result"><p><strong>01</strong> termina en <MathTex tex="(r_1,I)" />.</p><p>Intersección: rechaza, porque los ceros son impares.<br>Unión: acepta, porque el número de unos no es múltiplo de 3.</p></div>
<div v-click="2" class="note"><MathTex tex="\varepsilon" /> también permite distinguirlas: la intersección rechaza y la unión acepta, porque cero ceros es una cantidad par.</div>

---
clicks: 3
---

<div class="eyebrow">Construcción general</div>

# Autómata producto

<div class="rule"><MathTex tex="Q=Q_1\times Q_2,\qquad q_0=(q_{01},q_{02})" /></div>
<div v-click="1" class="rule"><MathTex tex="\delta((p,q),a)=(\delta_1(p,a),\delta_2(q,a))" /></div>
<div v-click="2" class="rule"><MathTex tex="\text{Intersección: } F=F_1\times F_2" /></div>
<div v-click="3" class="rule"><MathTex tex="\text{Unión: } F=(F_1\times Q_2)\cup(Q_1\times F_2)" /></div>
<p class="note">Los dos AFD son completos y usan el mismo alfabeto. En el ejercicio 12.c, «y» selecciona la intersección.</p>
