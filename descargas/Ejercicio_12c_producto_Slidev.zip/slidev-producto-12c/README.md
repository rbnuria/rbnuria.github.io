# Autómata producto: ejercicio 12.c

13 diapositivas con la plantilla Slidev de Modelos de Computación y pasos por clic. Autora de la presentación: Nuria Rodríguez Barroso.

Se resuelve el enunciado original mediante intersección y se desarrolla también la variante de unión. Los dos productos comparten transiciones y difieren en los estados finales. Los diagramas son componentes SVG editables en components/ProductGraph.vue.

Fuente del enunciado: Relacion_2.pdf, Modelos de Computación, Ingeniería Informática, Grupo C, 24/25, ejercicio 12.c. Desarrollo explicativo propio. Se conserva la atribución disponible en el documento.

Ejecutar `npm install` y `npm run dev`. Abrir http://localhost:3036/1. Avanzar con flecha derecha o barra espaciadora. El enlace de node_modules de esta copia local reutiliza las dependencias existentes; no se incluye en el ZIP.

PDF paso a paso: `npm run export -- --output ../pdf/Ejercicio_12c_producto_paso_a_paso.pdf`.

Preparada y revisada en local. La publicación en GitHub requiere el visto bueno explícito de Nuria.
